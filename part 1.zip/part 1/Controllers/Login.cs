﻿using Microsoft.AspNetCore.Mvc;

namespace part_1.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILogger<LoginController> _logger;
        public ActionResult Index()
        {
            return View();
        }

        // POST: Login
        [HttpPost]
        public ActionResult Index(string username, string password)
        {
            // TO DO: Implement login logic here
            // For now, just return a success message
            ViewBag.Message = "Login successful!";
            return View();
        }
    }
}
