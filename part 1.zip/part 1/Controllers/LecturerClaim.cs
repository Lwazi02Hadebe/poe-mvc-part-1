﻿using Microsoft.AspNetCore.Mvc;

namespace part_1.Controllers
{
    public class LecturerClaimController : Controller
    {
        private readonly ILogger<LecturerClaimController> _logger;
        public ActionResult Index()
        {
            return View();
        }

    }
}
