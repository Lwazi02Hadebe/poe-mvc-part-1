﻿using Microsoft.AspNetCore.Mvc;

namespace part_1.Controllers
{
    public class RegisterController : Controller
    {
        private readonly ILogger<RegisterController> _logger;
        public ActionResult Index()
        {
            return View();
        }

        // POST: RegisterLecturer
        [HttpPost]
        public ActionResult Index(string lecturerName, string lecturerEmail, string lecturerPassword)
        {
            // TO DO: Implement registration logic here
            // For now, just return a success message
            ViewBag.Message = "Lecturer registered successfully!";
            return View();
        }
    }
}
