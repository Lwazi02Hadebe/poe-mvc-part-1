﻿using Microsoft.AspNetCore.Mvc;

namespace part_1.Controllers
{
    public class ProgrammeCoordinatorController : Controller
    {
        private readonly ILogger<ProgrammeCoordinatorController> _logger;
        public ActionResult Index()
        {
            return View();
        }

    }
}
